<template>
  <div class="fixed inset-0 bg-black bg-opacity-40 z-50 flex items-center justify-center">
    <div class="bg-white p-6 rounded-xl shadow-2xl w-full max-w-6xl max-h-[90vh] overflow-y-auto relative">
      <button @click="$emit('close')" class="absolute top-4 right-4 text-gray-500 hover:text-black text-xl">&times;</button>

      <h2 class="text-2xl font-bold mb-6 text-center text-pink-600">📈 Аналіз впливу параметра</h2>

      <!-- Красивий перемикач типу варіації -->
      <div class="mb-6 flex flex-wrap justify-center gap-3">
        <button
          v-for="option in options"
          :key="option.value"
          @click="variationType = option.value"
          :class="[
            'px-4 py-1.5 rounded-full text-sm font-semibold shadow transition duration-200',
            variationType === option.value
              ? 'bg-pink-600 text-white'
              : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
          ]"
        >
          {{ option.label }}
        </button>
      </div>

      <!-- Ввідні дані -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
          <h3 class="text-sm font-semibold mb-1">🎯 Goal</h3>
          <textarea v-model="profile.goal" readonly class="textarea"></textarea>
        </div>
        <div>
          <h3 class="text-sm font-semibold mb-1">🧠 Skills</h3>
          <textarea v-model="profile.skills" readonly class="textarea"></textarea>
        </div>
        <div>
          <h3 class="text-sm font-semibold mb-1">👥 Team</h3>
          <textarea v-model="profile.team" readonly class="textarea"></textarea>
        </div>
      </div>

      <!-- Варіації -->
      <div class="mt-4">
        <h3 class="text-lg font-semibold mb-3">⚖️ Результати по варіаціях</h3>
        <div v-if="results.length" class="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div v-for="(res, index) in results" :key="index"
               class="p-4 border rounded-xl bg-white shadow hover:shadow-md transition text-sm">
            <p class="font-semibold text-gray-800 mb-2">
              <template v-if="variationType === 'weights'">
                🎯 goal: {{ res.weights.goal }}, 🧠 skills: {{ res.weights.skills }}, 👥 team: {{ res.weights.team }}
              </template>
              <template v-else-if="variationType === 'skills'">
                🧠 Навички: {{ res.profile.skills.join(', ') }}
              </template>
              <template v-else-if="variationType === 'team'">
                👥 Команда: {{ res.profile.team.join(', ') }}
              </template>
              <template v-else-if="variationType === 'goal'">
                🎯 Мета: {{ res.profile.goal }}
              </template>
            </p>

            <div class="bg-indigo-50 p-2 rounded border border-indigo-200 mb-2">
              <p class="font-semibold text-indigo-700">🧠 Rule-Based</p>
              <p class="text-indigo-800 font-medium mt-1">{{ res['Rule-Based'].weighted_category }}</p>
            </div>

            <div class="bg-emerald-50 p-2 rounded border border-emerald-200 mb-2">
              <p class="font-semibold text-emerald-700">🔎 Ontology-Based</p>
              <p class="text-emerald-800 font-medium mt-1">{{ res['Ontology-Based'].weighted_category }}</p>
            </div>

            <div class="bg-yellow-50 p-2 rounded border border-yellow-200">
              <p class="font-semibold text-yellow-700">🧩 Frame-Based</p>
              <p class="text-yellow-800 font-medium mt-1">{{ res['Frame-Based'].weighted_category }}</p>
            </div>
          </div>
        </div>
        <div v-else class="text-gray-600 text-sm italic">Очікується відповідь...</div>
      </div>

      <button @click="loadRandomProfile"
              class="mt-8 bg-yellow-500 hover:bg-yellow-600 text-white font-semibold text-sm px-5 py-2 rounded shadow flex items-center gap-2">
        🔄 Оновити дані
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import axios from 'axios'

const profile = ref({})
const results = ref([])
const variationType = ref('weights')

const options = [
  { label: 'Ваги', value: 'weights' },
  { label: 'Навички', value: 'skills' },
  { label: 'Команда', value: 'team' },
  { label: 'Мета', value: 'goal' }
]

const loadRandomProfile = async () => {
  try {
    const res = await fetch('http://localhost:8004/api/test-runs?count=1')
    const data = await res.json()
    const random = data[0]
    profile.value = random.profile
    await runVariationAnalysis()
  } catch (e) {
    console.error('Не вдалося отримати тестовий профіль:', e)
  }
}

const runVariationAnalysis = async () => {
  try {
    const response = await axios.post(`http://localhost:8004/api/analyze-${variationType.value}`, profile.value, {
      headers: { 'Content-Type': 'application/json' }
    })
    results.value = response.data
  } catch (error) {
    console.error('Помилка при порівнянні:', error)
  }
}

onMounted(loadRandomProfile)

watch(variationType, async () => {
  results.value = []
  await runVariationAnalysis()
})
</script>

<style scoped>
.textarea {
  @apply w-full p-2 border rounded mb-2 bg-gray-100 cursor-not-allowed text-sm;
}
</style>
