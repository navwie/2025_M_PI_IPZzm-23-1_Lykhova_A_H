<template>
  <div class="max-w-4xl mx-auto px-6 py-8 bg-gradient-to-br from-indigo-50 to-white shadow-xl rounded-2xl">
    <button @click="runTestProfiles"
              class="bg-emerald-600 mb-5 hover:bg-emerald-700 text-white px-5 py-2 rounded-lg shadow transition">
         Запустити тести
      </button>
    <div class="flex justify-between items-center mb-2">
      <h1 class="text-2xl font-extrabold text-indigo-700">Форма для порівняння методів баз знань</h1>
    </div>
     <div class="flex justify-between items-center mb-2">
      <h1 class="text-1xl font-extrabold text-indigo-700">Крок 1:</h1>
    </div>

    <form @submit.prevent="goToStep2" class="space-y-6">

      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-2">Навички:</label>
        <v-select
          v-model="profile.skills"
          :options="skillsOptions"
          multiple
          placeholder="Оберіть навички"
          class="w-full border rounded-lg shadow-sm"
        />
      </div>

      <!-- Experience -->
      <div v-if="profile.skills.length">
        <label class="block text-sm font-semibold text-gray-700 mb-2">Досвід по кожній навичці (роки):</label>
        <div v-for="skill in profile.skills" :key="skill" class="mb-2">
          <label :for="skill" class="block font-medium text-gray-600">{{ skill }}:</label>
          <input
            type="number"
            :id="skill"
            v-model="profile.experiencePerSkill[skill]"
            placeholder="Кількість років"
            min="0"
            class="w-full border rounded-md p-2 bg-white shadow-sm"
          />
        </div>
      </div>

      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-2">Команда (ролі):</label>
        <v-select
          v-model="profile.team"
          :options="teamOptions"
          multiple
          placeholder="Оберіть ролі членів команди"
          class="w-full border rounded-lg shadow-sm"
        />
      </div>

      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-2">Фінансування:</label>
        <div class="flex flex-col gap-1 text-sm text-gray-700">
          <label><input type="radio" value="є фінансування" v-model="profile.funding"> Є фінансування</label>
          <label><input type="radio" value="немає" v-model="profile.funding"> Немає</label>
          <label><input type="radio" value="в пошуку" v-model="profile.funding"> В пошуку</label>
        </div>
      </div>

      <!-- Weights -->
      <div>
        <h2 class="text-lg font-semibold text-indigo-700 mt-6 mb-2">Ваги критеріїв (1 - 5):</h2>
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Вага цілі (Goal):</label>
            <input type="number" v-model.number="profile.weights.goal" min="1" max="5" class="w-full border rounded-md p-2" />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Вага навичок (Skills):</label>
            <input type="number" v-model.number="profile.weights.skills" min="1" max="5" class="w-full border rounded-md p-2" />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Вага команди (Team):</label>
            <input type="number" v-model.number="profile.weights.team" min="1" max="5" class="w-full border rounded-md p-2" />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Вага досвіду (Experience):</label>
            <input type="number" v-model.number="profile.weights.experience" min="1" max="5" class="w-full border rounded-md p-2" />
          </div>
        </div>
      </div>

      <div class="flex justify-center pt-6">
        <button type="submit"
                class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-2 rounded-lg shadow-lg transition">
           Далі
        </button>
      </div>
    </form>
  </div>
</template>

<script>
import vSelect from 'vue-select';
import 'vue-select/dist/vue-select.css';

export default {
  components: { vSelect },
  data() {
    return {
      profile: {
        skills: [],
        experiencePerSkill: {},
        team: [],
        funding: "",
        weights: {
          goal: 1,
          skills: 1,
          team: 1,
          experience: 1
        }
      },
      skillsOptions: [
        "Програмування", "Технології", "Іновації", "Маркетинг", "Дизайн", "Управління", "Аналіз даних",
        "Продажі", "Створення контенту", "Консалтинг", "Фінанси", "Підтримка клієнтів",
        "Психологія", "Освіта", "Медицина", "Логістика", "Архітектура",
        "Виробництво", "Інженерія", "Наукові дослідження"
      ],
      teamOptions: [
        "Розробник", "Дизайнер", "Бізнес-аналітик", "Маркетолог", "Бухгалтер",
        "Продакт-менеджер", "Дослідник ринку", "Спеціаліст з продажів",
        "UI/UX дизайнер", "Юрист", "Вчений", "Менеджер з постачання",
        "Медик", "Освітній консультант", "Інженер", "HR-спеціаліст", "Психолог", "Агроном"
      ],
      skillMapping: {
        "Технології": "technology",
        "Іновації": "innovation",
        "Програмування": "programming",
        "Маркетинг": "marketing",
        "Дизайн": "design",
        "Управління": "management",
        "Аналіз даних": "data analysis",
        "Продажі": "sales",
        "Створення контенту": "content",
        "Консалтинг": "consulting",
        "Фінанси": "finance",
        "Підтримка клієнтів": "customer support",
        "Психологія": "psychology",
        "Освіта": "education",
        "Медицина": "medicine",
        "Логістика": "logistics",
        "Архітектура": "architecture",
        "Виробництво": "manufacturing",
        "Інженерія": "engineering",
        "Наукові дослідження": "research"
      }
    };
  },
  methods: {
    goToStep2() {
      const experiencePerSkill = {};
      const skillsInEnglish = [];

      this.profile.skills.forEach(skill => {
        const engSkill = this.skillMapping[skill] || skill;
        skillsInEnglish.push(engSkill);
        experiencePerSkill[engSkill] = this.profile.experiencePerSkill[skill] || 0;
      });

      const transformedProfile = {
        skills: skillsInEnglish.join(", "),
        experiencePerSkill: experiencePerSkill,
        team: this.profile.team.join(", "),
        funding: this.profile.funding,
        weights: this.profile.weights
      };

      this.$router.push({ name: 'Step2', params: { profile: transformedProfile } });
    },
    async runTestProfiles() {
      const response = await fetch('http://localhost:8004/api/test-runs?count=20');
      const data = await response.json();
      this.$router.push({ name: 'test-results', params: { results: data } });
    }
  }
};
</script>