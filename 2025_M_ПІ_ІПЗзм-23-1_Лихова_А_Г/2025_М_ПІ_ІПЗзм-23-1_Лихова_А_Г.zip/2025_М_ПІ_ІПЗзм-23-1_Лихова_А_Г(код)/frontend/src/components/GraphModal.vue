<template>
  <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-lg p-6 max-w-3xl w-full relative">
      <button @click="$emit('close')" 
              class="absolute top-2 right-2 text-xl font-bold">&times;</button>
      <h2 class="text-xl font-semibold mb-4">Графік середніх значень</h2>

      <label class="block mb-2 font-medium">Виберіть показник:</label>
      <select v-model="selectedMetric" class="border rounded px-2 py-1 mb-4">
        <option value="score">Score</option>
        <option value="matches">Matches</option>
        <option value="speed">Speed</option>
      </select>

      <canvas id="avgChart"></canvas>
    </div>
  </div>
</template>

<script>
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);

export default {
  props: ['results'],
  data() {
    return {
      selectedMetric: 'score',
      chartInstance: null
    };
  },
  mounted() {
    this.renderChart();
  },
  watch: {
    selectedMetric() {
      this.renderChart();
    }
  },
  methods: {
    renderChart() {
      if (this.chartInstance) {
        this.chartInstance.destroy();
      }

      const methods = ['Rule-Based', 'Ontology-Based', 'Frame-Based'];
      const defaultAverages = [];
      const weightedAverages = [];

      methods.forEach(method => {
        let defaultSum = 0, defaultCount = 0;
        let weightedSum = 0, weightedCount = 0;

        this.results.forEach(item => {
          // --- Default ---
          let defaultVal = Number(item[method].default[`default_${this.selectedMetric}`]) || 0;
          if (this.selectedMetric === 'speed') {
            defaultVal *= 1000;
          }
          if (!isNaN(defaultVal)) {
            defaultSum += defaultVal;
            defaultCount++;
          }

          // --- Weighted ---
          let weightedVal = Number(item[method].weighted[`weighted_${this.selectedMetric}`]) || 0;
          if (this.selectedMetric === 'speed') {
            weightedVal *= 1000;
          }
          if (!isNaN(weightedVal)) {
            weightedSum += weightedVal;
            weightedCount++;
          }
        });

        const avgDefault = defaultCount ? (defaultSum / defaultCount).toFixed(2) : 0;
        const avgWeighted = weightedCount ? (weightedSum / weightedCount).toFixed(2) : 0;

        defaultAverages.push(avgDefault);
        weightedAverages.push(avgWeighted);
      });

      const ctx = document.getElementById('avgChart').getContext('2d');

      this.chartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: methods,
          datasets: [
            {
              label: 'Default',
              data: defaultAverages,
              backgroundColor: '#3b82f6'
            },
            {
              label: 'Weighted',
              data: weightedAverages,
              backgroundColor: '#f97316'
            }
          ]
        },
        options: {
          responsive: true,
          scales: {
            y: {
              beginAtZero: true,
              title: {
                display: true,
                text: this.selectedMetric === 'speed' 
                  ? 'Speed (×1000)' 
                  : this.selectedMetric
              }
            }
          }
        }
      });
    }
  }
};
</script>
