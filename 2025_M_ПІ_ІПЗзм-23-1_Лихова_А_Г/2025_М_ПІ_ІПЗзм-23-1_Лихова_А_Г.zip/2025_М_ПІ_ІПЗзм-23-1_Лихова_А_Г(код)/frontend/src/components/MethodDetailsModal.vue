<template>
  <div v-if="show" class="fixed inset-0 bg-black bg-opacity-40 flex justify-center items-center z-50">
    <div class="bg-white w-full max-w-6xl p-6 rounded-lg shadow-xl overflow-y-auto max-h-[90vh]">
      <h2 class="text-xl font-semibold text-indigo-700 mb-4"> Деталі вибору стартапу</h2>

      <!-- Tabs -->
      <div class="flex space-x-4 mb-4 border-b pb-2">
        <button
          v-for="tab in tabs"
          :key="tab"
          :class="['px-4 py-1 rounded-t text-sm font-medium', currentTab === tab ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-700']"
          @click="currentTab = tab"
        >
          {{ tab }}
        </button>
      </div>

  <!-- Match Summary -->
      <div v-if="match[currentTab] !== undefined" class="mb-4 text-center text-base font-semibold">
        <span :class="match[currentTab] ? 'text-green-600' : 'text-red-600'">
           Збіг між Default та Weighted: {{ match[currentTab] ? 'Так — стартапи однакові' : 'Ні — стартапи різні' }}
        </span>
      </div>

      <!-- Side-by-side content -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm text-gray-800 leading-snug">
        <!-- Default -->
        <div v-if="formatted[currentTab]?.default" class="border-r pr-4">
          <h3 class="text-indigo-700 font-bold mb-2">🔹 Default режим</h3>
          <ul>
            <li v-for="(line, index) in formatted[currentTab].default" :key="'d' + index" class="mb-1">{{ line }}</li>
          </ul>
        </div>

        <!-- Weighted -->
        <div v-if="formatted[currentTab]?.weighted" class="pl-4">
          <h3 class="text-pink-700 font-bold mb-2">🔸 Weighted режим</h3>
          <ul>
            <li v-for="(line, index) in formatted[currentTab].weighted" :key="'w' + index" class="mb-1">{{ line }}</li>
          </ul>
        </div>
      </div>

      <div class="text-right mt-6">
        <button @click="$emit('close')" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
          Закрити
        </button>
      </div>
    </div>
  </div>
</template>

<script>
function formatBlock(d, method) {
  if (!d) return [];
  const category = d.default_category || '—';
  const idea = d.default_idea?.idea || '—';
  const explanation = d.default_explanation || '';
  const audience = d.default_idea?.audience?.join(', ') || '—';
  const model = d.default_idea?.businessModel?.join(', ') || '—';
  const innovation = d.default_idea?.innovationLevel?.join(', ') || '—';
  const values = d.default_idea?.values?.join(', ') || '—';

  const [rawHeader, ...rest] = explanation.split('|');
  const steps = rest.flatMap(s => s.split(';')).map(s => s.trim()).filter(Boolean);

  return [
    `• Метод: ${method}`,
    `• Обрана категорія: ${category}`,
    `• Як система прийняла рішення:`,
    `▶ ${rawHeader?.trim()}`,
    ...steps.map(s => `• ${s}`),
    ``,
    `💬 Висновок:`,
    `Ці умови дали найбільшу відповідність для категорії "${category}".`,
    ``,
    `• Обрана ідея: "${idea}"`,
    `• Аудиторія: ${audience}`,
    `• Бізнес-модель: ${model}`,
    `• Інноваційність: ${innovation}`,
    `• Цінності: ${values}`
  ];
}

export default {
  props: {
    show: Boolean,
    data: Object
  },
  data() {
    return {
      currentTab: 'Rule-Based',
      tabs: ['Rule-Based', 'Ontology-Based', 'Frame-Based']
    };
  },
  computed: {
    formatted() {
      const result = {};
      for (const method of this.tabs) {
        const d = this.data?.[method];
        if (!d) continue;

        result[method] = {
          default: formatBlock(d.default, method),
          weighted: formatBlock(d.weighted, method)
        };
      }
      return result;
    },
    match() {
      const result = {};
      for (const method of this.tabs) {
        const d = this.data?.[method];
        if (!d) continue;
        const cat1 = d.default?.default_category;
        const cat2 = d.weighted?.default_category;
        result[method] = cat1 && cat2 && cat1 === cat2;
      }
      return result;
    }
  }
};
</script>