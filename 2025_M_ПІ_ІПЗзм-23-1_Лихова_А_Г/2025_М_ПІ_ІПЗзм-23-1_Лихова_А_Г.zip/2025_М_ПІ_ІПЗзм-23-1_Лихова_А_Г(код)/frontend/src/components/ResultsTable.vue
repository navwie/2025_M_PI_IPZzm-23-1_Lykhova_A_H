<template>
  <div class="max-w-4xl mx-auto p-6 bg-white rounded-xl shadow-lg">
    <h1 class="text-3xl font-bold text-indigo-700 mb-8 text-center">📊 Результати порівняння стартапів</h1>

    <div v-for="(result, method) in results" :key="method" class="mb-8 border border-indigo-100 p-6 rounded-lg bg-indigo-50 shadow-sm">
      <h2 class="text-2xl font-semibold text-indigo-800 mb-4">{{ method }}</h2>

      <div class="grid grid-cols-2 gap-4 text-sm text-gray-700 mb-4">
        <div>
          <p class="text-gray-600">Категорія (Default):</p>
          <p class="font-medium text-gray-900">{{ result.default.default_category }}</p>
        </div>
        <div>
          <p class="text-gray-600">Категорія (Weighted):</p>
          <p class="font-medium text-gray-900">{{ result.weighted.weighted_category }}</p>
        </div>

        <div>
          <p class="text-gray-600">Головна ідея (Default):</p>
          <p class="font-medium text-gray-900">{{ result.default.default_idea.idea }}</p>
        </div>
        <div>
          <p class="text-gray-600">Головна ідея (Weighted):</p>
          <p class="font-medium text-gray-900">{{ result.weighted.weighted_idea.idea }}</p>
        </div>

        <div>
          <p class="text-gray-600">Оцінка (Default):</p>
          <p class="font-medium text-gray-900">{{ result.default.default_score }}</p>
        </div>
        <div>
          <p class="text-gray-600">Оцінка (Weighted):</p>
          <p class="font-medium text-gray-900">{{ result.weighted.weighted_score }}</p>
        </div>

        <div>
          <p class="text-gray-600">Збіги (Default):</p>
          <p class="font-medium text-gray-900">{{ result.default.default_matches }}</p>
        </div>
        <div>
          <p class="text-gray-600">Збіги (Weighted):</p>
          <p class="font-medium text-gray-900">{{ result.weighted.weighted_matches }}</p>
        </div>

        <div>
          <p class="text-gray-600">Швидкість (Default):</p>
          <p class="font-medium text-gray-900">{{ formatSpeed(result.default.default_speed) }} сек.</p>
        </div>
        <div>
          <p class="text-gray-600">Швидкість (Weighted):</p>
          <p class="font-medium text-gray-900">{{ formatSpeed(result.weighted.weighted_speed) }} сек.</p>
        </div>
      </div>

      <div class="bg-white p-4 border border-indigo-200 rounded-md">
        <p class="font-semibold text-indigo-700 mb-2">📝 Пояснення (Default):</p>
        <p class="text-gray-800">{{ result.default.default_explanation }}</p>
        <p class="font-semibold text-indigo-700 mt-4 mb-2">📝 Пояснення (Weighted):</p>
        <p class="text-gray-800">{{ result.weighted.weighted_explanation }}</p>
      </div>
    </div>

    <div class="text-center mt-8">
      <button @click="goHome"
              class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-3 rounded-lg shadow transition">
        🔁 Заповнити нову форму
      </button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      results: this.$route.params.results
    };
  },
  methods: {
    goHome() {
      this.$router.push({ name: 'StartupForm' });
    },
    formatSpeed(value) {
      if (!value || value === 0) return "менше 0.001";
      return value.toFixed(3);
    }
  }
};
</script>
