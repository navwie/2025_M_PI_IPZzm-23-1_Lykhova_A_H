<template>
    <div class="w-full mx-auto p-6 bg-white shadow-xl rounded-xl">
    <h1 class="text-2xl font-bold text-indigo-700 mb-6 text-center">📋 Результати тестових профілів</h1>

    <div class="flex flex-wrap justify-center gap-4 mb-4">
     

      <button @click="reloadResults"
              class="bg-yellow-500 hover:bg-yellow-600 text-white text-sm font-medium px-4 py-1.5 rounded shadow">
        🔄 Оновити тестові дані
      </button>
      <button @click="goBack"
              class="bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium px-4 py-1.5 rounded shadow">
        🔙 Назад до форми
      </button>
        <button @click="showAnalytics = true"
              class="bg-pink-600 hover:bg-pink-700 text-white text-sm font-medium px-4 py-1.5 rounded shadow">
        📈 Аналіз впливу ваг
      </button>
    </div>

    <GraphModal v-if="showGraph"
                :results="results"
                @close="showGraph = false" />

    <ComparisonExperiment v-if="showAnalytics" @close="showAnalytics = false" />

    <table class="w-full table-fixed border border-gray-300 text-xs rounded shadow">
      <thead class="bg-indigo-100 text-indigo-800">
        <tr>
          <th class="border px-2 py-1 w-8">№</th>
          <th class="border px-2 py-1 w-28">Навички</th>
          <th class="border px-2 py-1 w-28">Команда</th>
          <th class="border px-2 py-1 w-24">Фінанс.</th>
          <th class="border px-2 py-1 w-24">Ціль</th>
          <th class="border px-2 py-1 w-24">Тип</th>
          <th class="border px-2 py-1 w-44">Rule-Based</th>
          <th class="border px-2 py-1 w-44">Ontology</th>
          <th class="border px-2 py-1 w-44">Frame</th>
          <th class="border px-2 py-1 w-20">Збіг D</th>
          <th class="border px-2 py-1 w-20">Збіг W</th>
          <th class="border px-2 py-1 w-20">Більше</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(item, index) in results" :key="index" class="hover:bg-indigo-50">
          <td class="border px-2 py-1 text-center font-medium">{{ index + 1 }}</td>
          <td class="border px-2 py-1 whitespace-normal">{{ item.profile.skills }}</td>
          <td class="border px-2 py-1 whitespace-normal">{{ item.profile.team }}</td>
          <td class="border px-2 py-1 text-center">{{ item.profile.funding }}</td>
          <td class="border px-2 py-1 text-center">{{ item.profile.goal }}</td>
          <td class="border px-2 py-1 text-center">{{ item.profile.startupType.join(", ") }}</td>

          <!-- Rule-Based -->
          <td class="border px-2 py-1 whitespace-normal text-gray-700">
            <div>
              <span class="font-semibold">D:</span> <span class="italic text-indigo-800">{{ item["Rule-Based"].default.default_category }}</span><br>
              🧠 {{ item["Rule-Based"].default.default_idea.idea || item["Rule-Based"].default.default_idea || '—' }}
            </div>
            <div class="mt-1">
              <span class="font-semibold">W:</span> <span class="italic text-indigo-800">{{ item["Rule-Based"].weighted.weighted_category }}</span><br>
              🧠 {{ item["Rule-Based"].weighted.weighted_idea.idea || item["Rule-Based"].weighted.weighted_idea || '—' }}
            </div>
          </td>

          <!-- Ontology-Based -->
          <td class="border px-2 py-1 whitespace-normal text-gray-700">
            <div>
              <span class="font-semibold">D:</span> <span class="italic text-indigo-800">{{ item["Ontology-Based"].default.default_category }}</span><br>
              🧠 {{ item["Ontology-Based"].default.default_idea.idea || item["Ontology-Based"].default.default_idea || '—' }}
            </div>
            <div class="mt-1">
              <span class="font-semibold">W:</span> <span class="italic text-indigo-800">{{ item["Ontology-Based"].weighted.weighted_category }}</span><br>
              🧠 {{ item["Ontology-Based"].weighted.weighted_idea.idea || item["Ontology-Based"].weighted.weighted_idea || '—' }}
            </div>
          </td>

          <!-- Frame-Based -->
          <td class="border px-2 py-1 whitespace-normal text-gray-700">
            <div>
              <span class="font-semibold">D:</span> <span class="italic text-indigo-800">{{ item["Frame-Based"].default.default_category }}</span><br>
              🧠 {{ item["Frame-Based"].default.default_idea.idea || item["Frame-Based"].default.default_idea || '—' }}
            </div>
            <div class="mt-1">
              <span class="font-semibold">W:</span> <span class="italic text-indigo-800">{{ item["Frame-Based"].weighted.weighted_category }}</span><br>
              🧠 {{ item["Frame-Based"].weighted.weighted_idea.idea || item["Frame-Based"].weighted.weighted_idea || '—' }}
            </div>
          </td>

          <td class="border px-2 py-1 text-center font-semibold" :class="categoriesMatchDefault(item) ? 'text-green-600' : 'text-red-600'">
            {{ categoriesMatchDefault(item) ? 'Так' : 'Ні' }}
          </td>
          <td class="border px-2 py-1 text-center font-semibold" :class="categoriesMatchWeighted(item) ? 'text-green-600' : 'text-red-600'">
            {{ categoriesMatchWeighted(item) ? 'Так' : 'Ні' }}
          </td>
          <td class="border px-2 py-1 text-center">
            <button @click="openDetails(item)" class="text-blue-600 hover:underline text-xs">Детальніше</button>
          </td>
        </tr>
      </tbody>
    </table>
    <MethodDetailsModal :data="selectedItem" :show="showDetails" @close="closeDetails" />
  </div>
</template>

<script>
import GraphModal from './GraphModal.vue';
import ComparisonExperiment from './ComparisonExperiment.vue';

import MethodDetailsModal from './MethodDetailsModal.vue';

export default {
   components: { GraphModal, MethodDetailsModal, ComparisonExperiment },
  data() {
    return {
      showGraph: false,
      results: this.$route.params.results,
      selectedItem: null,
      showDetails: false,
      showAnalytics: false
    };
  },
    mounted() {
    this.reloadResults();
    },
  methods: {
    categoriesMatchDefault(item) {
      const categories = [
        item["Rule-Based"].default.default_category,
        item["Ontology-Based"].default.default_category,
        item["Frame-Based"].default.default_category
      ];
      return new Set(categories).size === 1;
    },
     openDetails(item) {
      this.selectedItem = item;
      this.showDetails = true;
    },
    closeDetails() {
      this.showDetails = false;
      this.selectedItem = null;
    },
    categoriesMatchWeighted(item) {
      const categories = [
        item["Rule-Based"].weighted.weighted_category,
        item["Ontology-Based"].weighted.weighted_category,
        item["Frame-Based"].weighted.weighted_category
      ];
      return new Set(categories).size === 1;
    },
    async reloadResults() {
      const response = await fetch('http://localhost:8004/api/test-runs?count=20');
      const newData = await response.json();
      this.results = newData;
    },
    goBack() {
      this.$router.push({ name: 'StartupForm' });
    }
  }
};
</script>