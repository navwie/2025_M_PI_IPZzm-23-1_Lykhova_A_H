
<template>
  <div class="max-w-3xl mx-auto p-6 bg-gradient-to-b from-white to-indigo-50 rounded-xl shadow-lg">
    <h2 class="text-2xl font-bold text-indigo-700 mb-6 text-center">Крок 2:</h2>

    <div v-for="(question, index) in questions" :key="index" class="mb-6 p-5 border border-indigo-100 bg-white rounded-lg shadow-sm">
      <p class="font-semibold text-gray-800 mb-3 text-lg">📌 {{ question.text }}</p>
      <div class="space-y-2">
        <label v-for="(option, optIndex) in question.options" :key="optIndex"
               class="flex items-center space-x-3 text-gray-700">
          <input
            type="radio"
            :name="'question_' + index"
            :value="option.code"
            v-model="answers[index]"
            class="form-radio text-indigo-600 focus:ring-indigo-500"
          />
          <span>{{ option.text }}</span>
        </label>
      </div>
    </div>

    <div class="flex justify-center mt-8">
      <button @click="submitAnswers"
              class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-3 rounded-lg shadow-md transition duration-300 ease-in-out">
         Отримати результат
      </button>
    </div>
  </div>
</template>

<script>
// JS logic remains the same — reusing your original code here for consistency.
</script>


<script>
export default {
  props: ["profile"],
  data() {
    return {
      questions: [
        {
          text: "Хто є вашою основною аудиторією?",
          options: [
            { code: "A", text: "Бізнеси (B2B)" },
            { code: "B", text: "Споживачі (B2C)" },
            { code: "C", text: "Освітні установи" },
            { code: "D", text: "Державні/громадські організації" }
          ]
        },
        {
          text: "Яка головна цінність вашого продукту?",
          options: [
            { code: "A", text: "Автоматизація процесів" },
            { code: "B", text: "Покращення користувацького досвіду" },
            { code: "C", text: "Підвищення ефективності навчання" },
            { code: "D", text: "Поліпшення здоров’я або безпеки" }
          ]
        },
        {
          text: "Яку бізнес-модель ви плануєте?",
          options: [
            { code: "A", text: "Підписка (Subscription)" },
            { code: "B", text: "Разовий продаж" },
            { code: "C", text: "Freemium" },
            { code: "D", text: "Реклама" }
          ]
        },
        {
        text: "Яку основну проблему або потребу ви хочете вирішити вашим стартапом?",
        options: [
            { code: "A", text: "Автоматизація процесів" },
            { code: "B", text: "Покращення здоров'я / медичні послуги" },
            { code: "C", text: "Освіта / навчання" },
            { code: "D", text: "Екологічні рішення" },
            { code: "E", text: "Фінансові послуги / оптимізація витрат" },
            { code: "F", text: "Кібербезпека / безпека даних" },
            { code: "G", text: "Маркетинг / залучення клієнтів" },
            { code: "H", text: "Розваги / ігри / інтерактив" },
            { code: "I", text: "Соціальний вплив / допомога спільнотам" },
            ]
        },

        {
          text: "Який рівень інноваційності вашого рішення?",
          options: [
            { code: "A", text: "Високий" },
            { code: "B", text: "Середній" },
            { code: "C", text: "Низький" },
            { code: "D", text: "Ще не визначено" }
          ]
        },
        {
          text: "Основний канал залучення клієнтів?",
          options: [
            { code: "A", text: "Цифровий маркетинг" },
            { code: "B", text: "Партнерські програми" },
            { code: "C", text: "Рекомендації" },
            { code: "D", text: "Інше" }
          ]
        }
      ],
      answers: Array(6).fill(null)
    };
  },
  methods: {
   async submitAnswers() {
    if (this.answers.includes(null)) {
        alert("Будь ласка, дайте відповіді на всі питання.");
        return;
    }

    const skillMapping = {
        "Технології": "technology",
        "Іновації": "innovation",
        "Програмування": "programming",
        "Маркетинг": "marketing",
        "Дизайн": "design",
        "Управління": "management",
        "Аналіз даних": "data analysis",
        "Продажі": "sales",
        "Створення контенту": "content",
        "Консалтинг": "consulting",
        "Фінанси": "finance",
        "Підтримка клієнтів": "customer support",
        "Психологія": "psychology",
        "Освіта": "education",
        "Медицина": "medicine",
        "Логістика": "logistics",
        "Архітектура": "architecture",
        "Виробництво": "manufacturing",
        "Інженерія": "engineering",
        "Наукові дослідження": "research"
    };

    const teamMapping = {
        "Розробник": "developer",
        "Дизайнер": "designer",
        "Бізнес-аналітик": "business analyst",
        "Маркетолог": "marketer",
        "Бухгалтер": "accountant",
        "Продакт-менеджер": "product manager",
        "Дослідник ринку": "market researcher",
        "Спеціаліст з продажів": "sales specialist",
        "UI/UX дизайнер": "ui/ux designer",
        "Юрист": "lawyer",
        "Вчений": "scientist",
        "Менеджер з постачання": "supply chain manager",
        "Медик": "medical specialist",
        "Освітній консультант": "education consultant",
        "Інженер": "engineer",
        "HR-спеціаліст": "hr specialist",
        "Психолог": "psychologist",
        "Агроном": "agronomist"
    };

    const fundingMapping = {
        "є фінансування": "has funding",
        "немає": "no funding",
        "в пошуку": "looking for funding"
    };

    // Mapping для додаткових відповідей:
    const audienceMap = {
        "A": "b2b",
        "B": "b2c",
        "C": "education",
        "D": "government"
    };

    const valueMap = {
        "A": "automation",
        "B": "user experience",
        "C": "learning efficiency",
        "D": "health/safety"
    };

    const businessModelMap = {
        "A": "subscription",
        "B": "one-time",
        "C": "freemium",
        "D": "advertising"
    };

    const innovationMap = {
        "A": "high",
        "B": "medium",
        "C": "low",
        "D": "undefined"
    };

    const goalMap = {
        "A": "automation",
        "B": "health",
        "C": "education",
        "D": "green",
        "E": "finance",
        "F": "cybersecurity",
        "G": "marketing",
        "H": "entertainment",
        "I": "social"
    };

    // Витягуємо відповіді:
    const audience = audienceMap[this.answers[0]];
    const value = valueMap[this.answers[1]];
    const businessModel = businessModelMap[this.answers[2]];
    const innovationLevel = innovationMap[this.answers[4]]; // питання 5
    const goal = goalMap[this.answers[3]];

    const skillsArray = Array.isArray(this.profile.skills)
        ? this.profile.skills
        : this.profile.skills.split(",").map(s => s.trim());

    const mappedSkills = skillsArray.map(s => skillMapping[s] || s);

    const teamArray = Array.isArray(this.profile.team)
        ? this.profile.team
        : this.profile.team.split(",").map(r => r.trim());

    const mappedTeam = teamArray.map(r => teamMapping[r] || r);

    const mappedFunding = fundingMapping[this.profile.funding] || this.profile.funding;

    const experiencePerSkill = {};
    for (const skill of skillsArray) {
        const engSkill = skillMapping[skill] || skill;
        experiencePerSkill[engSkill] = this.profile.experiencePerSkill[skill] || 0;
    }

    const payload = {
        skills: mappedSkills.join(", "),
        experiencePerSkill: experiencePerSkill,
        team: mappedTeam.join(", "),
        funding: mappedFunding,
        goal: goal,
        audience: audience,
        value: value,
        businessModel: businessModel,
        innovationLevel: innovationLevel,
        weights: this.profile.weights
    };

    console.log("Відправляємо payload:", payload);

    const response = await fetch('http://localhost:8004/api/compare-methods', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });

    const data = await response.json();

    this.$router.push({ name: 'results', params: { results: data } });
  }
}

};
</script>
