<template>
  <div class="flex flex-col min-h-screen bg-gray-50 text-gray-800">
    <!-- Header -->
    <header class="bg-gradient-to-r from-indigo-600 to-blue-600 text-white py-4 shadow-md">
      <div class="max-w-7xl mx-auto px-4 flex justify-between items-center">
        <h1 class="text-xl sm:text-2xl font-bold tracking-wide">
          🧠 Система порівняння методів баз знань • Rule-based • Ontology • Frame
        </h1>
      </div>
    </header>

    <!-- Main content -->
    <main class="flex-grow max-w-8xl mx-auto px-4 py-6">
      <router-view></router-view>
    </main>
=
    <!-- Footer -->
    <footer class="bg-indigo-700 text-white text-center py-3 text-sm mt-6 shadow-inner">
      © 2025 Система порівняння баз знань — Rule-based, Ontology, Frame
    </footer>
  </div>
</template>


<script>
export default {
  name: 'App'
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
}
</style>
