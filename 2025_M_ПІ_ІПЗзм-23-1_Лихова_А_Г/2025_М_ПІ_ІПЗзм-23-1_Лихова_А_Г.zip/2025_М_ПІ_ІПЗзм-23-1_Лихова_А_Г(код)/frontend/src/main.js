import Vue from 'vue';
import App from './App.vue';
import router from './router';  // Імпортуємо маршрутизатор
import '../src/assets/main.css';

Vue.config.productionTip = false;

new Vue({
  router,  // Підключаємо маршрутизатор
  render: h => h(App)
}).$mount('#app');
