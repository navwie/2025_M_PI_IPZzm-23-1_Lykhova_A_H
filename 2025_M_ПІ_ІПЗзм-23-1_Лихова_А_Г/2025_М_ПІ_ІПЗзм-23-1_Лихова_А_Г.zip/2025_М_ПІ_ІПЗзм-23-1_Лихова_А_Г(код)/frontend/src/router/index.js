import Vue from 'vue';
import Router from 'vue-router';

import StartupForm from '../components/StartupForm.vue';
import Step2 from '../components/StepTwo.vue';
import Results from '../components/ResultsTable.vue';
import TestResults from '../components/TestResults.vue';

Vue.use(Router);

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: 'StartupForm',
      component: StartupForm
    },
    {
      path: '/step2',
      name: 'Step2',
      component: Step2,
      props: true
    },
    {
      path: '/results',
      name: 'results',
      component: Results,
      props: true
    },
    {
        path: '/test-results',
        name: 'test-results',
        component: TestResults
      }
  ]
});
