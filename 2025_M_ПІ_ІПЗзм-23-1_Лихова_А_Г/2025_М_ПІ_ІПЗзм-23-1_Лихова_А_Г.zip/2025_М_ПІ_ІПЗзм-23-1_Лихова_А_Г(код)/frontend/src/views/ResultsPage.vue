<template>
  <div>
    <ResultsTable :results="results" /> <!-- передаємо отримані результати в таблицю -->
    <ComparisonChart :data="chartData" /> <!-- Графічне представлення результатів -->
  </div>
</template>

<script>
import ResultsTable from '@/components/ResultsTable.vue';
import ComparisonChart from '@/components/ComparisonChart.vue';

export default {
  name: 'ResultsPage',
  components: {
    ResultsTable,
    ComparisonChart,
  },
  data() {
    return {
      results: this.$route.params.results,  // Отримуємо результати з маршруту
      chartData: this.formatChartData(this.$route.params.results),
    }
  },
  methods: {
    formatChartData(results) {
      // Форматуємо дані для графіку
      return {
        labels: ['Rule-Based', 'Ontology-Based', 'Frame-Based'],
        datasets: [{
          data: [results['Rule-Based'], results['Ontology-Based'], results['Frame-Based']],
          backgroundColor: ['rgba(255, 99, 132, 0.2)', 'rgba(54, 162, 235, 0.2)', 'rgba(75, 192, 192, 0.2)'],
          borderColor: ['rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(75, 192, 192, 1)'],
          borderWidth: 1
        }]
      };
    },
  }
}
</script>

<style scoped>
/* Стилізація для сторінки результатів */
</style>
