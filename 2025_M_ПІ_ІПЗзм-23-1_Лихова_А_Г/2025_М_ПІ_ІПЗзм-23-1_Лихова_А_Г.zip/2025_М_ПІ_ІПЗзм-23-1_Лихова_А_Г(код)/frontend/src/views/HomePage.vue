<template>
  <div>
    <StartupForm />
  </div>
</template>

<script>
import StartupForm from '@/components/StartupForm.vue';

export default {
  name: 'HomePage',
  components: {
    StartupForm
  }
}
</script>

<style scoped>
/* Стилізація для домашньої сторінки */
</style>
