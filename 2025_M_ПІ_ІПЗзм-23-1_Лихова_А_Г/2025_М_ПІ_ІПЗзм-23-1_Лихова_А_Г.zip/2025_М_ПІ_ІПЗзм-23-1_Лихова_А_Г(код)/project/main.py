from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from services.profile_service import create_profile, Profile
from services.comparison_service import compare_methods
import random

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/api/compare-methods")
async def compare_methods_api(request: Request):
    profile_data = await request.json()

    import random
    weights = profile_data.get("weights", {
        "goal": random.randint(1, 5),
        "skills": random.randint(1, 5),
        "market": random.randint(1, 5),
        "experience": random.randint(1, 5)
    })
    profile = Profile(**profile_data)  # 🔥 Конвертуємо словник у Pydantic Profile
    results = compare_methods(profile, weights)
    return results

@app.get("/api/test-runs")
async def run_test_profiles(count: int = 20):
    test_results = []

    weights = {
        "goal": 3,
        "skills": 5,
        "team": 2,
        "experience": 5
    }

    skills_pool = [
        "programming", "technology", "innovation", "marketing", "design", "management", "data analysis",
        "sales", "content creation", "consulting", "finance", "customer support", "psychology",
        "education", "medicine", "logistics", "architecture", "manufacturing", "engineering", "research"
    ]

    team_pool = [
        "developer", "designer", "business analyst", "marketer", "accountant", "product manager",
        "market researcher", "sales specialist", "UI/UX designer", "lawyer", "scientist",
        "supply manager", "medic", "education consultant", "engineer", "HR specialist", "psychologist",
        "agronomist"
    ]

    funding_options = ["has funding", "no funding", "looking for funding"]

    goals_pool = [
        "automation", "healthcare", "education", "green solutions", "finance",
        "cybersecurity", "marketing", "gaming", "social impact"
    ]

    startup_types = ["Marketplace", "Platform", "Service", "Tool"]

    for _ in range(count):
        skills = ", ".join(random.sample(skills_pool, k=random.randint(2, 5)))
        team = ", ".join(random.sample(team_pool, k=random.randint(2, 5)))
        funding = random.choice(funding_options)
        goal = random.choice(goals_pool)
        startupType = random.sample(startup_types, k=random.randint(1, 2))

        experiencePerSkill = {
            skill: random.randint(1, 10)
            for skill in skills.split(", ")
        }

        profile = create_profile(
            skills=skills,
            experience="",
            team=team,
            funding=funding,
            idea="",
            experiencePerSkill=experiencePerSkill,
            goal=goal,
            startupType=startupType
        )

        result = compare_methods(profile, weights)

        test_results.append({
            "profile": {
                "skills": skills,
                "team": team,
                "funding": funding,
                "experiencePerSkill": experiencePerSkill,
                "goal": goal,
                "startupType": startupType,
                "weights": weights
            },
            "Rule-Based": result["Rule-Based"],
            "Ontology-Based": result["Ontology-Based"],
            "Frame-Based": result["Frame-Based"]
        })

    return test_results

@app.post("/api/compare-weight")
async def compare_weight_endpoint(request: Request):
    profile_data = await request.json()

    variations = [
        {"goal": 5, "skills": 1, "team": 1},
        {"goal": 1, "skills": 5, "team": 1},
        {"goal": 1, "skills": 1, "team": 5},
        {"goal": 3, "skills": 3, "team": 1},
        {"goal": 3, "skills": 1, "team": 3},
        {"goal": 1, "skills": 3, "team": 3}
    ]

    profile = Profile(**profile_data)
    results = []

    for weights in variations:
        comparison = compare_methods(profile, weights)
        result = {
            "weights": weights,
            "Rule-Based": comparison["Rule-Based"].get("weighted"),
            "Ontology-Based": comparison["Ontology-Based"].get("weighted"),
            "Frame-Based": comparison["Frame-Based"].get("weighted")
        }
        results.append(result)

    return results


@app.post("/api/analyze-skills")
async def analyze_skills(request: Request):
    profile_data = await request.json()
    profile = Profile(**profile_data)

    all_variants = [
        ["AI", "design"],
        ["marketing", "data analysis"],
        ["education", "psychology"],
        ["finance", "engineering"],
        ["content creation", "technology"],
        ["logistics", "medicine"]
    ]

    results = []
    for skill_list in all_variants:
        profile.skills = ", ".join(skill_list)
        comparison = compare_methods(profile, profile_data.get("weights"))
        results.append({
            "profile": {"skills": skill_list},
            "Rule-Based": comparison["Rule-Based"].get("weighted"),
            "Ontology-Based": comparison["Ontology-Based"].get("weighted"),
            "Frame-Based": comparison["Frame-Based"].get("weighted")
        })

    return results

@app.post("/api/analyze-team")
async def analyze_team(request: Request):
    profile_data = await request.json()
    profile = Profile(**profile_data)

    team_variants = [
        ["developer", "designer"],
        ["marketer", "business analyst"],
        ["engineer", "UI/UX designer"],
        ["lawyer", "psychologist"],
        ["HR specialist", "product manager"],
        ["scientist", "agronomist"]
    ]

    results = []
    for team_list in team_variants:
        profile.team = ", ".join(team_list)
        comparison = compare_methods(profile, profile_data.get("weights"))
        results.append({
            "profile": {"team": team_list},
            "Rule-Based": comparison["Rule-Based"].get("weighted"),
            "Ontology-Based": comparison["Ontology-Based"].get("weighted"),
            "Frame-Based": comparison["Frame-Based"].get("weighted")
        })

    return results

@app.post("/api/analyze-goal")
async def analyze_goal(request: Request):
    profile_data = await request.json()
    profile = Profile(**profile_data)

    goal_variants = [
        "education", "healthcare", "finance", "automation", "marketing", "cybersecurity"
    ]

    results = []
    for goal in goal_variants:
        profile.goal = goal
        comparison = compare_methods(profile, profile_data.get("weights"))
        results.append({
            "profile": {"goal": goal},
            "Rule-Based": comparison["Rule-Based"].get("weighted"),
            "Ontology-Based": comparison["Ontology-Based"].get("weighted"),
            "Frame-Based": comparison["Frame-Based"].get("weighted")
        })

    return results
@app.post("/api/analyze-weights")
async def analyze_weights(request: Request):
    profile_data = await request.json()

    variations = [
        {"goal": 5, "skills": 1, "team": 1},
        {"goal": 1, "skills": 5, "team": 1},
        {"goal": 1, "skills": 1, "team": 5},
        {"goal": 3, "skills": 3, "team": 1},
        {"goal": 3, "skills": 1, "team": 3},
        {"goal": 1, "skills": 3, "team": 3}
    ]

    profile = Profile(**profile_data)
    results = []

    for weights in variations:
        comparison = compare_methods(profile, weights)
        result = {
            "weights": weights,
            "Rule-Based": comparison["Rule-Based"].get("weighted"),
            "Ontology-Based": comparison["Ontology-Based"].get("weighted"),
            "Frame-Based": comparison["Frame-Based"].get("weighted")
        }
        results.append(result)

    return results