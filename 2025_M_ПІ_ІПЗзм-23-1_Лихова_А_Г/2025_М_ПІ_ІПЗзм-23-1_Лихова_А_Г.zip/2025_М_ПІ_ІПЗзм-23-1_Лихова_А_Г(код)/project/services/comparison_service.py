from services.answer_to_ideas import ANSWER_TO_IDEAS_MAPPING
from rapidfuzz import fuzz
import time
def find_best_idea(profile, category):
    from services.answer_to_ideas import ANSWER_TO_IDEAS_MAPPING
    ideas = ANSWER_TO_IDEAS_MAPPING.get(category, [])

    # Якщо ідеї — прості рядки (старий формат), повертаємо першу
    if not ideas or isinstance(ideas[0], str):
        return ideas[0] if ideas else "Ідея не знайдена"

    user_audience = profile.get("audience", "").lower()
    user_value = profile.get("value", "").lower()
    user_model = profile.get("businessModel", "").lower()
    user_innovation = profile.get("innovationLevel", "").lower()

    def score(idea):
        s = 0
        if user_audience in idea.get("audience", []):
            s += 1
        if user_model in idea.get("businessModel", []):
            s += 1
        if user_innovation in idea.get("innovationLevel", []):
            s += 1
        if user_value in idea.get("values", []):
            s += 1
        return s

    best_idea = max(ideas, key=score)
    return best_idea["idea"]


# ---------- КАТЕГОРІЇ ----------

categories = {
    "FinTech Startup": ["finance", "fintech", "financial", "banking", "investment",
                        "insurance", "cryptocurrency", "blockchain", "payments", "trading", "personal finance"],
    "EdTech Startup": ["education", "learning", "edtech", "e-learning", "courses",
                       "school", "university", "tutoring", "training", "mentoring", "online education"],
    "HealthTech Startup": ["medicine", "health", "medical", "biotech", "pharmaceutical",
                           "telemedicine", "fitness", "wellness", "healthcare", "therapy", "mental health"],
    "AI / Data Science": ["ai", "artificial intelligence", "machine learning", "deep learning", "data science",
                          "data analysis", "neural network", "big data", "analytics", "computer vision", "nlp"],
    "Marketing / Sales": ["marketing", "advertising", "seo", "content", "branding",
                          "sales", "crm", "lead generation", "social media", "promotion", "digital marketing"],
    "E-commerce / Marketplace": ["e-commerce", "online store", "retail", "shopping", "marketplace",
                                 "b2c", "dropshipping", "logistics", "supply chain", "product management", "inventory"],
    "Real Estate / PropTech": ["real estate", "property", "proptech", "rental", "mortgage",
                               "housing", "construction", "building", "architecture", "smart home", "urban"],
    "GreenTech / CleanTech": ["green", "cleantech", "renewable", "solar", "wind",
                              "energy", "recycling", "climate", "sustainability", "eco", "environmental"],
    "Gaming / Entertainment": ["game", "gaming", "video games", "entertainment", "streaming",
                               "media", "esports", "vr", "ar", "metaverse", "interactive"],
    "TravelTech / Hospitality": ["travel", "hospitality", "tourism", "hotel", "booking", "vacation", "trip", "flight", "airbnb", "trip planning", "experience travel"],
    "IT Startup": ["software", "development", "devops", "teamwork", "infrastructure", "automation", "programming", "it", "technology", "coding", "learning"]
}

# ---------- RULE-BASED ----------

def rule_based_category(profile, weights=None):
    goal = profile.goal.lower()
    skills = profile.skills.lower()
    team = profile.team.lower()

    best_category = None
    best_score = 0

    for category, keywords in categories.items():
        score = 0
        for keyword in keywords:
            if fuzz.partial_ratio(keyword, goal) >= 70:
                score += 70 * (weights.get("goal", 1) if weights else 1)
            if fuzz.partial_ratio(keyword, skills) >= 70:
                score += 70 * (weights.get("skills", 1) if weights else 1)
            if fuzz.partial_ratio(keyword, team) >= 70:
                score += 70 * (weights.get("team", 1) if weights else 1)

        if score > best_score:
            best_category = category
            best_score = score

    if best_category:
        return best_category, f"Rule-Based: {best_category} (score: {best_score})"
    else:
        return "No category found", "Жодного збігу fuzzy не знайдено."

def rule_based_method(profile):
    category, explanation = rule_based_category(profile)
    return generate_result(profile, category, explanation)

def rule_based_method_weighted(profile, weights):
    category, explanation = rule_based_category(profile, weights)
    return generate_result(profile, category, explanation, weights)

# ---------- ONTOLOGY ----------

def ontology_based_category(profile, weights=None):
    text = (profile.goal + " " + profile.skills + " " + profile.team).lower()
    best_category = None
    best_score = 0

    for category, keywords in categories.items():
        score = 0
        for keyword in keywords:
            if keyword in text:
                weight = (weights.get("goal", 1) + weights.get("skills", 1) + weights.get("team", 1)) if weights else 1
                score += 100 * weight
        if score > best_score:
            best_category = category
            best_score = score

    if best_category:
        return best_category, f"Ontology-Based: {best_category} (score: {best_score})"
    else:
        return "No category found", "Прямих збігів не знайдено."

def ontology_based_method(profile):
    category, explanation = ontology_based_category(profile)
    return generate_result(profile, category, explanation)

def ontology_based_method_weighted(profile, weights):
    category, explanation = ontology_based_category(profile, weights)
    return generate_result(profile, category, explanation, weights)

# ---------- FRAME ----------

def frame_based_category(profile, weights=None):
    team_roles = profile.team.lower()
    skills = profile.skills.lower()
    goal = profile.goal.lower()

    frame_scores = {cat: 0 for cat in categories.keys()}

    def add_score(cat, base, weight):
        frame_scores[cat] += base * (weight or 1)

    # Аналіз ролей у команді (team_roles)
    for category, keywords in categories.items():
        for keyword in keywords:
            if keyword in team_roles or fuzz.partial_ratio(keyword, team_roles) >= 80:
                add_score(category, 10, (weights or {}).get("team", 1))

    # Аналіз навичок (skills)
    for category, keywords in categories.items():
        for keyword in keywords:
            if keyword in skills or fuzz.partial_ratio(keyword, skills) >= 80:
                add_score(category, 10, (weights or {}).get("skills", 1))

    # Аналіз цілей (goal)
    for category, keywords in categories.items():
        for keyword in keywords:
            if keyword in goal or fuzz.partial_ratio(keyword, goal) >= 80:
                add_score(category, 10, (weights or {}).get("goal", 1))

    best_category = max(frame_scores, key=frame_scores.get)
    best_score = frame_scores[best_category]

    if best_score > 0:
        return best_category, f"Frame-Based: {best_category} (score: {best_score})"
    else:
        return "No category found", "Frame: не знайдено відповідних ролей або цілей."

def frame_based_method(profile):
    category, explanation = frame_based_category(profile)
    return generate_result(profile, category, explanation)

def frame_based_method_weighted(profile, weights):
    category, explanation = frame_based_category(profile, weights)
    return generate_result(profile, category, explanation, weights)

# ---------- МЕТРИКИ ----------

def calculate_metrics(profile, idea_text, category, weights=None):
    if weights is None:
        weights = {
            "goal": 1,
            "skills": 1,
            "team": 1,
            "experience": 1
        }

    explanation = []
    score = 50
    matches = 0

    category_keywords = categories.get(category, [])
    category_text = " ".join(category_keywords).lower()

    # Skills
    for skill in profile.skills.split(", "):
        similarity = fuzz.partial_ratio(skill.lower(), category_text)
        if similarity >= 60:
            weight = weights.get("skills", 1)
            matches += 1
            score += 10 * weight
            explanation.append(f"Збіг навички: {skill} (fuzzy {similarity}%, вага {weight})")

    # Team roles
    for role in profile.team.split(", "):
        similarity = fuzz.partial_ratio(role.lower(), category_text)
        if similarity >= 60:
            weight = weights.get("team", 1)
            matches += 1
            score += 10 * weight
            explanation.append(f"Збіг роль: {role} (fuzzy {similarity}%, вага {weight})")

    # Goal
    similarity_goal = fuzz.partial_ratio(profile.goal.lower(), category_text)
    if similarity_goal >= 60:
        weight = weights.get("goal", 1)
        matches += 1
        score += 10 * weight
        explanation.append(f"Збіг цілі (goal) (fuzzy {similarity_goal}%, вага {weight})")

    # Experience
    experience_score = sum(profile.experiencePerSkill.values()) // 10
    if experience_score > 0:
        weight_exp = weights.get('experience', 1)
        score += experience_score * weight_exp
        explanation.append(f"Досвід: {experience_score} балів (вага {weight_exp})")

    score = min(score, 500)

    return {
        "score": score,
        "matches": matches,
        "explanation": "; ".join(explanation) if explanation else "Збігів не знайдено"
    }

# ---------- ГОЛОВНА ФУНКЦІЯ ----------

def compare_methods(profile, weights):
    return {
        "Rule-Based": {
            "default": rule_based_method(profile),
            "weighted": rule_based_method_weighted(profile, weights)
        },
        "Ontology-Based": {
            "default": ontology_based_method(profile),
            "weighted": ontology_based_method_weighted(profile, weights)
        },
        "Frame-Based": {
            "default": frame_based_method(profile),
            "weighted": frame_based_method_weighted(profile, weights)
        }
    }

def generate_result(profile, category, explanation, weights=None):
    idea = find_best_idea(profile, category)

    start = time.time()
    metrics = calculate_metrics(profile, idea, category, weights)
    end = time.time()

    speed = round(end - start, 6)
    if speed < 0.001:
        speed = 0.001

    return {
        "default_category": category,
        "default_idea": idea,
        "default_score": metrics["score"],
        "default_matches": metrics["matches"],
        "default_explanation": explanation + " | " + metrics["explanation"],
        "default_speed": speed,
        "weighted_score": metrics["score"],
        "weighted_matches": metrics["matches"],
        "weighted_category": category,
        "weighted_idea": idea,
        "weighted_explanation": explanation + " | " + metrics["explanation"],
        "weighted_speed": speed
    }

def find_best_idea(profile, category):
    ideas = ANSWER_TO_IDEAS_MAPPING.get(category, [])
    return ideas[0] if ideas else "No idea available"
