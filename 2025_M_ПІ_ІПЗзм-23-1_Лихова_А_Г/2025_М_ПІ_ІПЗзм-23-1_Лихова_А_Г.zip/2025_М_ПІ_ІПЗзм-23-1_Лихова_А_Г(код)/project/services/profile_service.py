from pydantic import BaseModel
from typing import Dict, List, Optional


# 🔶 Основна модель профілю користувача
class Profile(BaseModel):
    skills: str
    team: str
    funding: str

    # Необов'язкові поля з дефолтами
    experience: Optional[str] = ""
    idea: Optional[str] = ""
    experiencePerSkill: Optional[Dict[str, int]] = {}
    startupType: Optional[List[str]] = []
    goal: Optional[str] = ""
    market: Optional[str] = ""
    budget: Optional[str] = ""
    launchTimeline: Optional[str] = ""


# 🔷 Функція для створення профілю (опціональна — якщо хочеш динамічно створювати з аргументів)
def create_profile(
    skills: str,
    team: str,
    funding: Optional[str] = "",
    experience: Optional[str] = "",
    idea: Optional[str] = "",
    experiencePerSkill: Optional[Dict[str, int]] = None,
    startupType: Optional[List[str]] = None,
    goal: Optional[str] = "",
    market: Optional[str] = "",
    budget: Optional[str] = "",
    launchTimeline: Optional[str] = ""
) -> Profile:
    return Profile(
        skills=skills,
        team=team,
        funding=funding,
        experience=experience,
        idea=idea,
        experiencePerSkill=experiencePerSkill or {},
        startupType=startupType or [],
        goal=goal,
        market=market,
    )