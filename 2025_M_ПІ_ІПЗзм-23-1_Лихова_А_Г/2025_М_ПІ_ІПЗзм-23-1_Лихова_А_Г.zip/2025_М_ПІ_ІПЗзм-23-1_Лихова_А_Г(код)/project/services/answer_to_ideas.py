ANSWER_TO_IDEAS_MAPPING = {
    "FinTech Startup": [
        {
            "idea": "Платформа мікроінвестування",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "finance",
                "automation"
            ]
        },
        {
            "idea": "Інструмент для бюджетування малого бізнесу",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "one-time",
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "finance",
                "user experience"
            ]
        },
        {
            "idea": "Платформа мікроінвестування v3",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "finance",
                "automation"
            ]
        },
        {
            "idea": "Платформа мікроінвестування v4",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "finance",
                "automation"
            ]
        },
        {
            "idea": "Інструмент для бюджетування малого бізнесу v5",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "one-time",
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "finance",
                "user experience"
            ]
        },
        {
            "idea": "Платформа мікроінвестування v6",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "finance",
                "automation"
            ]
        }
    ],
    "EdTech Startup": [
        {
            "idea": "Платформа для адаптивного навчання",
            "audience": [
                "education"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "learning",
                "personalization"
            ]
        },
        {
            "idea": "Сервіс для репетиторів і студентів",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "education",
                "connection"
            ]
        },
        {
            "idea": "Сервіс для репетиторів і студентів v3",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "education",
                "connection"
            ]
        },
        {
            "idea": "Сервіс для репетиторів і студентів v4",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "education",
                "connection"
            ]
        },
        {
            "idea": "Платформа для адаптивного навчання v5",
            "audience": [
                "education"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "learning",
                "personalization"
            ]
        },
        {
            "idea": "Платформа для адаптивного навчання v6",
            "audience": [
                "education"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "learning",
                "personalization"
            ]
        }
    ],
    "HealthTech Startup": [
        {
            "idea": "Телемедична платформа",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "healthcare",
                "remote access"
            ]
        },
        {
            "idea": "AI-діагностика захворювань",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "one-time"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "ai",
                "medicine"
            ]
        },
        {
            "idea": "Телемедична платформа v3",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "healthcare",
                "remote access"
            ]
        },
        {
            "idea": "Телемедична платформа v4",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "healthcare",
                "remote access"
            ]
        },
        {
            "idea": "AI-діагностика захворювань v5",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "one-time"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "ai",
                "medicine"
            ]
        },
        {
            "idea": "Телемедична платформа v6",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "healthcare",
                "remote access"
            ]
        }
    ],
    "AI / Data Science": [
        {
            "idea": "AI-платформа для бізнесу",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "automation",
                "efficiency"
            ]
        },
        {
            "idea": "Сервіс генерації контенту на базі ШІ",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "content",
                "ai"
            ]
        },
        {
            "idea": "Автоматизована система прогнозування продажів",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "prediction",
                "sales"
            ]
        },
        {
            "idea": "AI-платформа для бізнесу v4",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "automation",
                "efficiency"
            ]
        },
        {
            "idea": "Сервіс генерації контенту на базі ШІ v5",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "content",
                "ai"
            ]
        },
        {
            "idea": "AI-платформа для бізнесу v6",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "automation",
                "efficiency"
            ]
        }
    ],
    "Marketing / Sales": [
        {
            "idea": "CRM з AI-рекомендаціями",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "ai",
                "crm"
            ]
        },
        {
            "idea": "Сервіс аналізу конкурентів",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "one-time"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "marketing",
                "analytics"
            ]
        },
        {
            "idea": "CRM з AI-рекомендаціями v3",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "ai",
                "crm"
            ]
        },
        {
            "idea": "Сервіс аналізу конкурентів v4",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "one-time"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "marketing",
                "analytics"
            ]
        },
        {
            "idea": "CRM з AI-рекомендаціями v5",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "ai",
                "crm"
            ]
        },
        {
            "idea": "Сервіс аналізу конкурентів v6",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "one-time"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "marketing",
                "analytics"
            ]
        }
    ],
    "E-commerce / Marketplace": [
        {
            "idea": "Онлайн маркетплейс для нішевих товарів",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "marketplace",
                "specialized"
            ]
        },
        {
            "idea": "Система керування замовленнями для e-commerce",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "e-commerce",
                "orders"
            ]
        },
        {
            "idea": "Онлайн маркетплейс для нішевих товарів v3",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "marketplace",
                "specialized"
            ]
        },
        {
            "idea": "Система керування замовленнями для e-commerce v4",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "e-commerce",
                "orders"
            ]
        },
        {
            "idea": "Система керування замовленнями для e-commerce v5",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "e-commerce",
                "orders"
            ]
        },
        {
            "idea": "Система керування замовленнями для e-commerce v6",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "e-commerce",
                "orders"
            ]
        }
    ],
    "Real Estate / PropTech": [
        {
            "idea": "Платформа для бронювання нерухомості",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "real estate",
                "booking"
            ]
        },
        {
            "idea": "Інструмент для управління орендою",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "one-time"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "real estate",
                "management"
            ]
        },
        {
            "idea": "Платформа для бронювання нерухомості v3",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "real estate",
                "booking"
            ]
        },
        {
            "idea": "Платформа для бронювання нерухомості v4",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "real estate",
                "booking"
            ]
        },
        {
            "idea": "Платформа для бронювання нерухомості v5",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "real estate",
                "booking"
            ]
        },
        {
            "idea": "Платформа для бронювання нерухомості v6",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "real estate",
                "booking"
            ]
        }
    ],
    "GreenTech / CleanTech": [
        {
            "idea": "Система моніторингу викидів CO2",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "environment",
                "data"
            ]
        },
        {
            "idea": "Маркетплейс екотоварів",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "eco",
                "products"
            ]
        },
        {
            "idea": "Система моніторингу викидів CO2 v3",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "environment",
                "data"
            ]
        },
        {
            "idea": "Маркетплейс екотоварів v4",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "eco",
                "products"
            ]
        },
        {
            "idea": "Маркетплейс екотоварів v5",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "eco",
                "products"
            ]
        },
        {
            "idea": "Система моніторингу викидів CO2 v6",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "environment",
                "data"
            ]
        }
    ],
    "Gaming / Entertainment": [
        {
            "idea": "Мобільна гра з AR",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "gaming",
                "ar"
            ]
        },
        {
            "idea": "Інтерактивна платформа для стрімінгу",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "entertainment",
                "interaction"
            ]
        },
        {
            "idea": "Інтерактивна платформа для стрімінгу v3",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "entertainment",
                "interaction"
            ]
        },
        {
            "idea": "Мобільна гра з AR v4",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "gaming",
                "ar"
            ]
        },
        {
            "idea": "Інтерактивна платформа для стрімінгу v5",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "entertainment",
                "interaction"
            ]
        },
        {
            "idea": "Мобільна гра з AR v6",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "gaming",
                "ar"
            ]
        }
    ],
    "TravelTech / Hospitality": [
        {
            "idea": "Платформа бронювання турів",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "travel",
                "booking"
            ]
        },
        {
            "idea": "Мобільний додаток для планування поїздок",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "planning",
                "travel"
            ]
        },
        {
            "idea": "Платформа бронювання турів v3",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "travel",
                "booking"
            ]
        },
        {
            "idea": "Платформа бронювання турів v4",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "travel",
                "booking"
            ]
        },
        {
            "idea": "Платформа бронювання турів v5",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "travel",
                "booking"
            ]
        },
        {
            "idea": "Мобільний додаток для планування поїздок v6",
            "audience": [
                "b2c"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "planning",
                "travel"
            ]
        }
    ],
    "IT Startup": [
        {
            "idea": "Сервіс підбору фахівців для IT-команд",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "automation",
                "teamwork"
            ]
        },
        {
            "idea": "Платформа навчання сучасним IT-технологіям",
            "audience": [
                "b2c",
                "education"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "education",
                "user experience"
            ]
        },
        {
            "idea": "Сервіс підбору фахівців для IT-команд v3",
            "audience": [
                "b2b"
            ],
            "businessModel": [
                "subscription"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "automation",
                "teamwork"
            ]
        },
        {
            "idea": "Платформа навчання сучасним IT-технологіям v4",
            "audience": [
                "b2c",
                "education"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "education",
                "user experience"
            ]
        },
        {
            "idea": "Платформа навчання сучасним IT-технологіям v5",
            "audience": [
                "b2c",
                "education"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "education",
                "user experience"
            ]
        },
        {
            "idea": "Платформа навчання сучасним IT-технологіям v6",
            "audience": [
                "b2c",
                "education"
            ],
            "businessModel": [
                "freemium"
            ],
            "innovationLevel": [
                "high"
            ],
            "values": [
                "education",
                "user experience"
            ]
        }
    ],
    "No category found": [
        {
            "idea": "Універсальна ідея для стартапу",
            "audience": [
                "general"
            ],
            "businessModel": [
                "unknown"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "flexibility"
            ]
        },
        {
            "idea": "Універсальна ідея для стартапу v2",
            "audience": [
                "general"
            ],
            "businessModel": [
                "unknown"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "flexibility"
            ]
        },
        {
            "idea": "Універсальна ідея для стартапу v3",
            "audience": [
                "general"
            ],
            "businessModel": [
                "unknown"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "flexibility"
            ]
        },
        {
            "idea": "Універсальна ідея для стартапу v4",
            "audience": [
                "general"
            ],
            "businessModel": [
                "unknown"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "flexibility"
            ]
        },
        {
            "idea": "Універсальна ідея для стартапу v5",
            "audience": [
                "general"
            ],
            "businessModel": [
                "unknown"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "flexibility"
            ]
        },
        {
            "idea": "Універсальна ідея для стартапу v6",
            "audience": [
                "general"
            ],
            "businessModel": [
                "unknown"
            ],
            "innovationLevel": [
                "medium"
            ],
            "values": [
                "flexibility"
            ]
        }
    ]
}