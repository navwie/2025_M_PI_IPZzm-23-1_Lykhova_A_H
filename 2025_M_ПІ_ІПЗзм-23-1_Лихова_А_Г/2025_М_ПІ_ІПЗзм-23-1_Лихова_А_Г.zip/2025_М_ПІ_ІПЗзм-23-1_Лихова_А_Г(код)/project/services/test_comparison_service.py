# test_comparison_service.py

from services.comparison_service import compare_methods
from services.diagnosis_service import Profile

# Тестовий профіль користувача
test_profile = Profile(
    skills="programming, marketing",
    experience="5",
    team="yes",
    funding="yes",
    idea="IT application"
)

# Перевірка результатів порівняння
results = compare_methods(test_profile)
assert results["Rule-Based"] > 0, "Rule-Based method failed"
assert results["Ontology-Based"] > 0, "Ontology-Based method failed"
assert results["Frame-Based"] > 0, "Frame-Based method failed"
