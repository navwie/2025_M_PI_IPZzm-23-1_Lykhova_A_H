# -------------------- Категорії --------------------

CATEGORIES = {
    "IT Startup": ["programming", "technology", "innovation", "data analysis", "automation", "design", "security"],
    "Marketing Startup": ["marketing", "content", "advertising", "sales", "market research", "branding", "customer service"],
    "Eco Startup": ["sustainability", "green", "environment", "innovation", "logistics", "waste management", "data analysis"],
    "HealthTech Startup": ["health", "medical", "research", "data analysis", "biotech", "automation", "security"],
    "EdTech Startup": ["education", "teaching", "learning", "content", "technology", "innovation", "data analysis"],
    "FinTech Startup": ["finance", "investment", "banking", "data analysis", "automation", "security", "programming"],
    "Travel Startup": ["travel", "tourism", "booking", "logistics", "sales", "customer service", "technology"],
    "E-commerce Startup": ["sales", "e-commerce", "retail", "marketing", "technology", "customer service", "design"]
}

TEAM_KEYWORDS = {
    "IT Startup": ["developer", "ui/ux designer", "designer", "data scientist", "business analyst", "engineer"],
    "Marketing Startup": ["marketer", "content manager", "market researcher", "sales specialist", "psychologist"],
    "Eco Startup": ["environmentalist", "logistics specialist", "researcher", "agronomist"],
    "HealthTech Startup": ["medical specialist", "biotech researcher", "data scientist", "psychologist", "scientist"],
    "EdTech Startup": ["education consultant", "teacher", "content creator", "psychologist"],
    "FinTech Startup": ["finance analyst", "lawyer", "accountant", "developer", "business analyst"],
    "Travel Startup": ["travel agent", "logistics specialist", "customer support", "supply chain manager"],
    "E-commerce Startup": ["sales specialist", "product manager", "customer support", "designer", "marketer"]
}

def get_experience_dict(profile):
    if hasattr(profile, "experiencePerSkill"):
        return profile.experiencePerSkill or {}
    elif hasattr(profile, "experience"):
        try:
            import json
            return json.loads(profile.experience)
        except:
            return {}
    return {}

def calculate_scores(profile):
    skills = [s.strip().lower() for s in profile.skills.split(",") if s.strip()]
    team = [t.strip().lower() for t in profile.team.split(",") if t.strip()]
    experience_dict = get_experience_dict(profile)

    scores = {}
    category_experience = {}
    category_matches = {}

    for category, keywords in CATEGORIES.items():
        score = 0
        total_experience = 0
        matches = 0

        for keyword in keywords:
            if keyword in skills:
                score += 1
                matches += 1
                exp = float(experience_dict.get(keyword, 0))
                score += exp
                total_experience += exp

        for role in TEAM_KEYWORDS.get(category, []):
            if role in team:
                score += 1
                matches += 1

        if profile.funding and profile.funding != "no funding":
            score += 1

        scores[category] = round(score, 2)
        category_experience[category] = total_experience
        category_matches[category] = matches

    return scores, category_experience, category_matches

class RuleBasedDiagnosis:
    def evaluate(self, profile):
        scores, _, _ = calculate_scores(profile)
        best_category = max(scores, key=scores.get)
        return scores[best_category], best_category

class OntologyBasedDiagnosis:
    def evaluate(self, profile):
        scores, category_experience, _ = calculate_scores(profile)
        best_category = max(category_experience, key=category_experience.get)
        return scores[best_category], best_category

class FrameBasedDiagnosis:
    def evaluate(self, profile):
        scores, _, category_matches = calculate_scores(profile)
        best_category = max(category_matches, key=category_matches.get)
        return scores[best_category], best_category
